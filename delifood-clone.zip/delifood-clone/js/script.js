/* ================================================
   DELIFOOD – Main JavaScript
   ================================================ */

(function () {
  'use strict';

  /* ---------- DOM Elements ---------- */
  const header = document.getElementById('header');
  const hamburgerBtn = document.getElementById('hamburger-btn');
  const navMenu = document.getElementById('nav-menu');
  const navLinks = document.querySelectorAll('.header__nav-link');
  const menuCategories = document.querySelectorAll('.menu-category');

  /* ---------- Mobile Nav Overlay ---------- */
  const overlay = document.createElement('div');
  overlay.classList.add('nav-overlay');
  document.body.appendChild(overlay);

  /* ---------- Hamburger Toggle ---------- */
  function toggleNav() {
    hamburgerBtn.classList.toggle('active');
    navMenu.classList.toggle('active');
    overlay.classList.toggle('active');
    document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
  }

  hamburgerBtn.addEventListener('click', toggleNav);
  overlay.addEventListener('click', toggleNav);

  navLinks.forEach(function (link) {
    link.addEventListener('click', function () {
      if (navMenu.classList.contains('active')) {
        toggleNav();
      }
    });
  });

  /* ---------- Header Scroll Shadow ---------- */
  let lastScrollY = 0;

  function handleScroll() {
    const scrollY = window.scrollY;
    if (scrollY > 20) {
      header.classList.add('header--scrolled');
    } else {
      header.classList.remove('header--scrolled');
    }
    lastScrollY = scrollY;
  }

  window.addEventListener('scroll', handleScroll, { passive: true });

  /* ---------- Scroll Reveal for Menu Categories ---------- */
  function revealOnScroll() {
    const triggerBottom = window.innerHeight * 0.88;

    menuCategories.forEach(function (category) {
      const categoryTop = category.getBoundingClientRect().top;

      if (categoryTop < triggerBottom) {
        category.classList.add('visible');
      }
    });
  }

  window.addEventListener('scroll', revealOnScroll, { passive: true });
  window.addEventListener('load', revealOnScroll);

  /* ---------- Smooth Scroll for Nav Links ---------- */
  navLinks.forEach(function (link) {
    link.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId.startsWith('#')) {
        e.preventDefault();
        const target = document.querySelector(targetId);
        if (target) {
          const headerHeight = header.offsetHeight;
          const targetPosition = target.getBoundingClientRect().top + window.scrollY - headerHeight - 10;
          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
          });
        }
      }
    });
  });

  /* ---------- WhatsApp Float Show/Hide on Scroll ---------- */
  const whatsappFloat = document.getElementById('whatsapp-float');
  let floatVisible = true;

  function handleFloatVisibility() {
    const scrollY = window.scrollY;
    if (scrollY > 300 && !floatVisible) {
      whatsappFloat.style.opacity = '1';
      whatsappFloat.style.pointerEvents = 'auto';
      floatVisible = true;
    }
    if (scrollY <= 300 && floatVisible && window.innerWidth > 560) {
      // Keep visible on mobile always
    }
  }

  window.addEventListener('scroll', handleFloatVisibility, { passive: true });

  /* ---------- Active Nav Link Highlight ---------- */
  const sections = document.querySelectorAll('section[id], main[id], footer[id]');

  function updateActiveLink() {
    const scrollY = window.scrollY + header.offsetHeight + 50;

    sections.forEach(function (section) {
      const sectionTop = section.getBoundingClientRect().top + window.scrollY;
      const sectionHeight = section.offsetHeight;
      const sectionId = section.getAttribute('id');

      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        navLinks.forEach(function (link) {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#' + sectionId) {
            link.classList.add('active');
          }
        });
      }
    });
  }

  window.addEventListener('scroll', updateActiveLink, { passive: true });

  /* ---------- Image Error Handling ---------- */
  document.querySelectorAll('img').forEach(function (img) {
    img.addEventListener('error', function () {
      this.style.display = 'none';
      const placeholder = document.createElement('div');
      placeholder.className = 'image-placeholder';
      placeholder.textContent = '📷';
      placeholder.style.width = '100%';
      placeholder.style.height = '100%';
      this.parentNode.appendChild(placeholder);
    });
  });

  /* ---------- Initial State ---------- */
  handleScroll();

})();
